const express = require('express');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes');
const sliderRoutes = require('./routes/sliderRoutes');
const jobRoutes = require('./routes/jobRoutes');
const path = require('path');
const cors = require("cors");
const {prettifyResponse} = require('./utils/prettifyResponse');
require('dotenv').config();

const app = express();

app.use(prettifyResponse);
const port = process.env.PORT

app.use(express.urlencoded({extended: true}));
app.use(bodyParser.json());
app.use(cors());

app.use('/api/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/api/users', userRoutes);
app.use('/api/slider', sliderRoutes);
app.use('/api/job', jobRoutes);
// Serve static files from the 'uploads' directory

app.listen(port, ()=>{
    console.log(`Server is listening ${port}`)
})
