const express = require("express");
const upload = require("../utils/sliderMulter");
const sliderController = require("../controllers/sliderController");
const {sliderIdMiddleware} = require("../middlewares/sliderIdMiddleware");

const router = express.Router();
 router.get("/", sliderController.getAllSliders);
 router.get("/:id", sliderController.getSliderById);
 router.post("/", sliderIdMiddleware, upload.single("slider_img"), sliderController.createSlider);
 router.put('/:id', upload.single('slider_img'), sliderController.updateSlider);
 router.delete('/:id', sliderController.deleteSlider);
// router.post("/", upload.none(),(req, res)=>{
//     console.log("slider data request", req.body)
// })
module.exports = router;