
const express = require('express');
const userController = require('../controllers/userController');
const upload = require('../utils/multer');
const  {userIdMiddleware} = require('../middlewares/userIdMiddleware');
const router = express.Router();

router.get('/', userController.getAllUsers);
router.get('/:id', userController.getUserById);
router.post('/', userIdMiddleware, upload.single('u_img'),userController.createUser);
router.post('/:id', upload.single('u_img'),userController.updateUser);
router.delete('/:id', userController.deleteUser);

module.exports = router;