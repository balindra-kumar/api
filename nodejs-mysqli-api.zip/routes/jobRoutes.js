const express = require("express");
const upload = require("../utils/jobMulter"); // Updated to jobMulter
const jobController = require("../controllers/jobController"); // Updated controller reference
const { jobIdMiddleware } = require("../middlewares/jobIdMiddleware");

const router = express.Router();

router.get("/", jobController.getAllJobs);
router.get("/:id", jobController.getJobById);
router.post("/", jobIdMiddleware, upload.single("job_img"), jobController.createJob);
router.put("/:id", upload.single("job_img"), jobController.updateJob);
router.delete("/:id", jobController.deleteJob);

module.exports = router;
