
const sliderIdMiddleware = (req, res, next) => {
    req.slider_id = Math.floor(10000000 + Math.random() * 90000000);
    next();
}
module.exports = {sliderIdMiddleware}