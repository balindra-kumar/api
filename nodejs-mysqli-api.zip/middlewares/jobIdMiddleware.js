
const jobIdMiddleware = (req, res, next) => {
    req.job_id = Math.floor(10000000 + Math.random() * 90000000);
    next();
}
module.exports = {jobIdMiddleware}