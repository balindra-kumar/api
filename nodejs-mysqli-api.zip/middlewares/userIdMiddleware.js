
const userIdMiddleware = (req, res, next) => {
    req.user_id = Math.floor(10000000 + Math.random() * 90000000);
    next();
}
module.exports = {userIdMiddleware}