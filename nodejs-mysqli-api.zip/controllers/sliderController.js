
const sliderModel  = require('../models/sliderModel');
const responseHandler = require('../utils/responseHandler');

const path = require("path");
const fs = require("fs");

const sliderController = {
    getAllSliders: async (req, res)=>{
        try{
            const sliders = await sliderModel.getAllSliders();
            return responseHandler.success(res, sliders);
        }catch(error){
            return responseHandler.error(res, error);
        }
    },
    getSliderById: async (req, res)=>{
        try{
            const slider = await sliderModel.getSliderById(req.params.id);
            return responseHandler.success(res, slider);
        }catch(error){
            return responseHandler.error(res, error);
        }
    },
    createSlider: async (req, res)=>{
        try{
            const {slider_title, slider_desc, slider_link} = req.body;

            const duplicateEntryId = await sliderModel.getSliderId(slider_title);
            console.log("getting slider title", slider_title);
            if(duplicateEntryId){
                return responseHandler.error(res, "Duplicate Entry Found");
            }

            const userImg = req.file.path ? req.file.path : null;
           
            const newSlider = {
                slider_id: req.slider_id,
                slider_title,
                slider_desc,
                slider_link,
                slider_img: userImg.replace(/\\/g, '/')
            }
            
            const slider = await sliderModel.createSlider(newSlider);
            return responseHandler.success(res, slider);
        }catch(error){
            return responseHandler.error(res, error);
        }
    },
    updateSlider: async (req, res)=>{
        try{
            const userId = req.params.id;
           
            const {slider_title, slider_desc, slider_link } = req.body;
            const existingImage = req.body.slider_img; // Ensure this is passed if no new file is uploaded
            if(!slider_title || !slider_desc || !slider_link){
                return responseHandler.error(res, "All fields are required");
            }
            // Handle file upload (if any)
            let userImg = existingImage; // Default to existing image
            if (req.file) {
                userImg = req.file.path.replace(/\\/g, '/'); // Use new image path
                console.log("New Image Uploaded:", userImg);
                // Delete the old image file (if it exists)
                if (existingImage) {
                    const imagePath = path.join(__dirname, '../uploads/', existingImage);
                    if (fs.existsSync(imagePath)) {
                        fs.unlinkSync(imagePath); // Delete old image file
                        console.log('Old image deleted:', existingImage);
                    }
                }
            }

            const user = {
                slider_title,
                slider_desc,
                slider_link,
                slider_img: userImg,
                
            }
            console.log("slider-image is", user,userId)
            const updatedUser = await sliderModel.updateSliderModal(user, userId);
            return responseHandler.success(res, updatedUser);
            
        }catch(error){
            return responseHandler.error(res, error);
        }
    },
    deleteSlider: async (req, res)=>{
        try{
            const userId = req.params.id;
            const userIdImg = await sliderModel.getSliderId(userId);
           
              // Delete the image file if it exists
              if (userIdImg.slider_img) {
                const imagePath = path.join(__dirname,"..", userIdImg.slider_img);
               
                if (fs.existsSync(imagePath)) {
                    try {
                        fs.unlinkSync(imagePath);
                        console.log("Image deleted:", imagePath);
                    } catch (unlinkError) {
                        console.error("Error deleting image:", unlinkError);
                        return responseHandler.error(res, "Error deleting image", 500);
                    }
                } else {
                    console.warn("Image file not found:", imagePath);
                }
            }
            const deletedUser = await sliderModel.deleteSliderModel(userId);
            
            return responseHandler.success(res, deletedUser);
           
        }catch(error){
            return responseHandler.error(res, error);
        }
    }
}
module.exports = sliderController;