const jobModel = require('../models/jobModel');
const responseHandler = require('../utils/responseHandler');

const path = require("path");
const fs = require("fs");

const jobController = {
    // Get all jobs
    getAllJobs: async (req, res) => {
        try {
            const jobs = await jobModel.getAllJobs();
            return responseHandler.success(res, jobs);
        } catch (error) {
            return responseHandler.error(res, error);
        }
    },

    // Get job by ID
    getJobById: async (req, res) => {
        try {
            const job = await jobModel.getJobById(req.params.id);
            return responseHandler.success(res, job);
        } catch (error) {
            return responseHandler.error(res, error);
        }
    },

    // Create a new job
    createJob: async (req, res) => {
        try {
            const { job_title, job_desc, job_link, job_skills, job_salary, job_exp, job_type, job_cat, job_location } = req.body;

            const duplicateJob = await jobModel.getJobByTitle(job_title);
            if (duplicateJob) {
                return responseHandler.error(res, "Duplicate Job Title Found");
            }

            const jobImg = req.file ? req.file.path.replace(/\\/g, '/') : null;

            const newJob = {
                job_id: req.job_id,
                job_title,
                job_desc,
                job_link,
                job_skills,
                job_img: jobImg,
                job_salary,
                job_exp,
                job_type,
                job_cat,
                job_location,
                created_at: new Date(),
                updated_at: new Date()
            };

            const jobId = await jobModel.createJob(newJob);
            return responseHandler.success(res, { job_id: jobId });
        } catch (error) {
            return responseHandler.error(res, error);
        }
    },

    // Update a job
    updateJob: async (req, res) => {
        try {
            const jobId = req.params.id;
            const { job_title, job_desc, job_link, job_skills, job_salary, job_exp, job_type, job_cat, job_location } = req.body;
            const existingImage = req.body.job_img; // Ensure this is passed if no new file is uploaded

            if (!job_title || !job_desc || !job_link) {
                return responseHandler.error(res, "All required fields must be filled.");
            }

            // Handle file upload (if any)
            let jobImg = existingImage;
            if (req.file) {
                jobImg = req.file.path.replace(/\\/g, '/'); // Use new image path
                console.log("New Image Uploaded:", jobImg);
                
                // Delete old image if it exists
                if (existingImage) {
                    const imagePath = path.join(__dirname, '../uploads/', existingImage);
                    if (fs.existsSync(imagePath)) {
                        fs.unlinkSync(imagePath);
                        console.log("Old Image Deleted:", existingImage);
                    }
                }
            }

            const updatedJob = {
                job_title,
                job_desc,
                job_link,
                job_skills,
                job_img: jobImg,
                job_salary,
                job_exp,
                job_type,
                job_cat,
                job_location,
                updated_at: new Date()
            };

            const result = await jobModel.updateJob(updatedJob, jobId);
            return responseHandler.success(res, result);
        } catch (error) {
            return responseHandler.error(res, error);
        }
    },

    // Delete a job
    deleteJob: async (req, res) => {
        try {
            const jobId = req.params.id;
            const job = await jobModel.getJobById(jobId);

            // Delete job image if it exists
            if (job && job.job_img) {
                const imagePath = path.join(__dirname, "..", job.job_img);
                if (fs.existsSync(imagePath)) {
                    try {
                        fs.unlinkSync(imagePath);
                        console.log("Image Deleted:", imagePath);
                    } catch (unlinkError) {
                        console.error("Error Deleting Image:", unlinkError);
                        return responseHandler.error(res, "Error deleting image", 500);
                    }
                } else {
                    console.warn("Image File Not Found:", imagePath);
                }
            }

            const deletedJob = await jobModel.deleteJob(jobId);
            return responseHandler.success(res, deletedJob);
        } catch (error) {
            return responseHandler.error(res, error);
        }
    }
}

module.exports = jobController;
