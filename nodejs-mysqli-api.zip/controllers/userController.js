const path = require("path");
const fs = require("fs");
const responseHandler = require("../utils/responseHandler");
const User = require("../models/userModel");

const userController = {

    getAllUsers: async (req, res)=>{
        try{
            const users = await User.getAllUsers();
            return responseHandler.success(res, users); 
        }catch(error){
            return responseHandler.error(res, error);
        }
    },
    getUserById: async (req, res)=>{
        try{
            const users = await User.getUserById(req.params.id);
            return responseHandler.success(res, users); 
        }catch(error){
            return responseHandler.error(res, error);
        }
    },
    createUser: async (req, res)=>{
        try{

        
            console.log('Request Body:', req.body); // Log all the text fields
            console.log('Uploaded File:', req.file); // Log the uploaded file (should not be undefined)
    

            // const genId = Math.floor(100000 + Math.random() * 900000);
            // req.user_id = genId; // Set user_id for Multer to use
            const { u_name, u_email, u_password, u_mobile, u_dob} = req.body;
            if(!u_name, !u_email, !u_password, !u_mobile, !u_dob, !req.file){

                
                return responseHandler.error(res, "All fields are required");
            }

            // Check if a user already exists with the same email or mobile number
            const existingUserByEmail = await User.getUserByEmail(u_email); // Assuming getUserByEmail method is defined
            if (existingUserByEmail) {
                return responseHandler.error(res, "Email already exists.");
            }

            const existingUserByMobile = await User.getUserByMobile(u_mobile); // Assuming getUserByMobile method is defined
            if (existingUserByMobile) {
                return responseHandler.error(res, "Mobile number already exists.");
            }
            
            const userImg = req.file.path ? req.file.path : null;
            const user ={
                user_id: req.user_id,
                u_name,
                u_email,
                u_password,
                u_mobile,
                u_dob,
                u_img: userImg.replace(/\\/g, '/'),
            }
            
            
            const newUser = await User.createUser(user);
            return responseHandler.success(res, newUser);
        }catch(error){
            return responseHandler.error(res, error);
        }
    },
    updateUser: async (req, res)=>{
        try{
            const userId = req.params.id;
           
            const {u_name, u_email, u_password, u_mobile, u_dob, u_img:existingImage } = req.body;
            if(!u_name, !u_email, !u_password, !u_mobile, !u_dob){
                return responseHandler.error(res, "All fields are required");
            }
            // Handle file upload (if any)
            let userImg = existingImage; // Default to existing image
            if (req.file) {
                userImg = req.file.path.replace(/\\/g, '/'); // Use new image path

                // Delete the old image file (if it exists)
                if (existingImage && fs.existsSync(path.join(__dirname, existingImage))) {
                    fs.unlinkSync(path.join(__dirname, existingImage)); // Delete the old image file
                     console.log('Old image deleted:', existingImage);
                }
            }

            const user = {
                u_name,
                u_email,
                u_password,
                u_mobile,
                u_dob,
                u_img: userImg
            }
            console.log(user)
            const updatedUser = await User.updateUserModal(user, userId);
            console.log("Affected rows:", updatedUser); 
            return responseHandler.success(res, "Data is updated successfully");
            
        }catch(error){
            return responseHandler.error(res, error);
        }
    },
    deleteUser: async (req, res)=>{
        try{
            const userId = req.params.id;
            const userIdImg = await User.getUserById(userId);
           
              // Delete the image file if it exists
              if (userIdImg.u_img) {
                const imagePath = path.join(__dirname,"..", userIdImg.u_img);
               
                if (fs.existsSync(imagePath)) {
                    try {
                        fs.unlinkSync(imagePath);
                        console.log("Image deleted:", imagePath);
                    } catch (unlinkError) {
                        console.error("Error deleting image:", unlinkError);
                        return responseHandler.error(res, "Error deleting image", 500);
                    }
                } else {
                    console.warn("Image file not found:", imagePath);
                }
            }
            const deletedUser = await User.deleteUserModel(userId);
            
            return responseHandler.success(res, deletedUser);
           
        }catch(error){
            return responseHandler.error(res, error);
        }
    }
}
module.exports = userController;