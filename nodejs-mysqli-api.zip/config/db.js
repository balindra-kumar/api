const mysql = require('mysql2/promise');
require('dotenv').config();

const connection = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "123456",
    database: "study",
    port: 3306,
    connectTimeout: 10000 // Set timeout to 10 seconds
})
connection.getConnection()
    .then(() => console.log("Database connected successfully"))
    .catch(err => console.error("Database connection failed:", err));

module.exports = connection;