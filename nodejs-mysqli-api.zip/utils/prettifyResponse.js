const prettifyResponse = (req, res, next) => {
   
    res.json = (data) => {
        const prettyData = JSON.stringify({
            success: true,
            status: res.statusCode,
            data: data
        }, null, 2); // Beautify JSON with indentation

        res.setHeader("Content-Type", "application/json"); // Ensure JSON content-type
        res.send(prettyData);
    };

    next();
};

module.exports = { prettifyResponse };
