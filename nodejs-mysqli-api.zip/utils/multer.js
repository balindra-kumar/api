const multer = require('multer');
const path = require('path');

// Storage configuration for multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './uploads'); // Save files in the 'uploads' directory
    },
    filename: (req, file, cb) => {
        // Use the user ID from the request parameters or body for the filename
        const userId = req.params.id || req.body.user_id || req.user_id; // Adjust based on your route or request structure
        if (!userId) {
            return cb(new Error('User ID is required'), null);
        }

        const customName = `user-${userId}`; // Custom filename
        const fileExtension = path.extname(file.originalname); // Get the file extension
        cb(null, `${customName}${fileExtension}`); // Save the file with custom name and original extension
    }
});

// Multer upload configuration
const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB file size limit
    fileFilter: (req, file, cb) => {ls
        // Validate file type (e.g., allow only images)
        const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (allowedMimeTypes.includes(file.mimetype)) {
            cb(null, true); // Accept the file
        } else {
            cb(new Error('Invalid file type. Only JPEG, PNG, and GIF are allowed.'), false);
        }
    }
});

module.exports = upload;