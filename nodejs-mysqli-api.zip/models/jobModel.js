const connection = require('../config/db');

const jobModel = {
    // Prevent duplicate job entries based on job title
    getJobByTitle: async (title) => {
        const sql = "SELECT * FROM jobs WHERE job_title = ?";
        const [rows] = await connection.query(sql, [title]);
        return rows.length > 0 ? rows[0] : null;
    },

    // Get all jobs
    getAllJobs: async () => {
        const [rows] = await connection.query("SELECT * FROM jobs");
        return rows;
    },

    // Get job by ID
    getJobById: async (id) => {
        const [rows] = await connection.query("SELECT * FROM jobs WHERE job_id = ?", [id]);
        return rows[0];
    },

    // Create a new job
    createJob: async (job) => {
        const [rows] = await connection.query("INSERT INTO jobs SET ?", job);
        return rows.insertId;
    },

    // Update a job by ID
    updateJob: async (job, job_id) => {
        // Destructure job object
        const { job_title, job_desc, job_link, job_skills, job_img, job_salary, job_exp, job_type, job_cat, job_location } = job;

        const [rows] = await connection.query(
            `UPDATE jobs 
             SET job_title = ?, job_desc = ?, job_link = ?, job_skills = ?, 
                 job_img = ?, job_salary = ?, job_exp = ?, job_type = ?, 
                 job_cat = ?, job_location = ? 
             WHERE job_id = ?`,
            [job_title, job_desc, job_link, job_skills, job_img, job_salary, job_exp, job_type, job_cat, job_location, job_id]
        );

        console.log("Update result: ", rows.affectedRows);
        return rows.affectedRows;
    },

    // Delete a job by ID
    deleteJob: async (id) => {
        const [rows] = await connection.query("DELETE FROM jobs WHERE job_id = ?", [id]);
        return rows.affectedRows;
    }
}

module.exports = jobModel;
