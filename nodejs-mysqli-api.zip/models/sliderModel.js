const connection = require('../config/db');

const sliderModel = {
    //duplicate entry prevent
    getSliderId: async (id)=>{
        const sql = "select * from sliders where slider_title=?";
        const [rows] = await connection.query(sql, [id]);
        return rows.length > 0 ? rows[0] : null;
    },
  
    getAllSliders: async()=>{
        const[rows] = await connection.query("select * from sliders");
        return rows;
    },
    getSliderById: async (id)=>{
        const [rows] = await connection.query("select * from sliders", [id]);
        return rows[0];
    },
    
    createSlider: async (slider)=>{
        const [rows] = await connection.query("INSERT INTO sliders SET ?", slider);
        return rows.insertId;
    },
    updateSliderModal : async (slider, slider_id)=>{
        // Destructure correct values from 'slider' object
        const { slider_title, slider_desc, slider_link, slider_img } = slider;
        const [rows] = await connection.query("UPDATE sliders SET slider_title = ?, slider_desc = ?, slider_link = ?, slider_img = ? WHERE slider_id = ?",
        [slider_title, slider_desc, slider_link, slider_img, slider_id]);
        console.log("Update result: ",  rows.affectedRows);
        return rows.affectedRows;
    },
    deleteSliderModel : async (id)=>{
        const [rows] = await connection.query("DELETE FROM sliders WHERE slider_id = ?", [id]);
        return rows.affectedRows;
    }
}

module.exports = sliderModel;