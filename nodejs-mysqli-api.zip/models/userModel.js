const connection = require('../config/db');
const Users = {
    getAllUsers : async()=>{
        const [rows] = await connection.query("select * from users");
        return rows;
    },
    getUserById: async(id)=>{
        const [rows] = await connection.query("select * from users where user_id = ?", [id]);
        return rows[0];
    },
     // Method to find a user by email
     getUserByEmail: async (email) => {
        const query = 'SELECT * FROM users WHERE u_email = ?';
        const [rows] = await connection.query(query, [email]);
        return rows.length > 0 ? rows[0] : null; // Return the user or null if not found
    },

    // Method to find a user by mobile number
    getUserByMobile: async (mobile) => {
        const query = 'SELECT * FROM users WHERE u_mobile = ?';
        const [rows] = await connection.query (query, [mobile]);
        return rows.length > 0 ? rows[0] : null; // Return the user or null if not found
    },
    createUser : async(user)=>{
        const [rows] = await connection.query("INSERT INTO users SET ?", user);
        return rows.insertId;
    },
    updateUserModal : async (user, id)=>{
      
        const [rows] = await connection.query("UPDATE users SET u_name = ?, u_email = ?, u_password = ?, u_mobile = ?, u_dob = ?, u_img = ? WHERE user_id = ?",
        [user.u_name, user.u_email, user.u_password, user.u_mobile, user.u_dob, user.u_img, id]);
        console.log("Update result: ",  rows.affectedRows);
        return rows.affectedRows;
    },
    deleteUserModel : async (id)=>{
        const [rows] = await connection.query("DELETE FROM users WHERE user_id = ?", [id]);
        return rows.affectedRows;
    }

}

module.exports = Users;